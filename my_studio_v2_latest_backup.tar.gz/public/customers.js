document.addEventListener('DOMContentLoaded', () => {
  const token = sessionStorage.getItem('authToken');
  const tableBody = document.getElementById('customer-table-body');
  const sendBtn = document.getElementById('btn-send-line');
  const customerForm = document.getElementById('customer-form');
  
  let customersData = [];
  let currentLineUserId = null;

  async function loadCustomers() {
    try {
      const res = await fetch('/api/customers', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      customersData = await res.json();
      
      if (!customersData || customersData.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center py-5 text-muted">ไม่พบข้อมูลลูกค้าในระบบ</td></tr>';
        return;
      }
      
      tableBody.innerHTML = customersData.map(c => {
        const pic = c.linePictureUrl ? '<img src="' + c.linePictureUrl + '" class="rounded-circle me-2" width="32">' : '<div class="bg-secondary rounded-circle me-2" style="width:32px;height:32px"></div>';
        const lineStatus = c.lineUserId ? '<span class="badge bg-success">Connected</span>' : '<span class="badge bg-light text-dark">Not Linked</span>';
        const lastActive = c.lastActive ? new Date(c.lastActive).toLocaleString('th-TH') : '-';
        
        return `<tr>
          <td>
            <div class="d-flex align-items-center">
              ${pic}
              <div>
                <div class="fw-bold">${c.name}</div>
                <div class="text-muted small">${c.company || (c.lineDisplayName || 'No LINE Link')}</div>
              </div>
            </div>
          </td>
          <td>${lineStatus}</td>
          <td>${c.phone || '-'}</td>
          <td>${lastActive}</td>
          <td>
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-primary" onclick="openMessageModal('${c.lineUserId}', '${c.name}')" ${!c.lineUserId ? 'disabled' : ''}>
                💬 ส่งข้อความ
              </button>
              <button class="btn btn-sm btn-outline-secondary" onclick="openCustomerModal('${c._id}')">
                ✏️ แก้ไข
              </button>
            </div>
          </td>
        </tr>`;
      }).join('');
    } catch (e) {
      console.error('Load error:', e);
      tableBody.innerHTML = '<tr><td colspan="5" class="text-center py-5 text-danger">เกิดข้อผิดพลาดในการโหลดข้อมูล</td></tr>';
    }
  }

  window.openMessageModal = (userId, name) => {
    if (!userId || userId === 'undefined') {
        alert('ลูกค้านี้ยังไม่ได้เชื่อมต่อกับ LINE');
        return;
    }
    currentLineUserId = userId;
    document.getElementById('target-customer-name').textContent = name;
    document.getElementById('line-message-text').value = '';
    const modal = new bootstrap.Modal(document.getElementById('sendMessageModal'));
    modal.show();
  };

  window.openCustomerModal = (id = null) => {
    const modalTitle = document.getElementById('customerModalTitle');
    const form = document.getElementById('customer-form');
    form.reset();
    document.getElementById('customer-id').value = id || '';

    if (id) {
      modalTitle.textContent = 'แก้ไขข้อมูลลูกค้า';
      const c = customersData.find(item => item._id === id);
      if (c) {
        document.getElementById('cust-name').value = c.name || '';
        document.getElementById('cust-company').value = c.company || '';
        document.getElementById('cust-taxId').value = c.taxId || '';
        document.getElementById('cust-phone').value = c.phone || '';
        document.getElementById('cust-email').value = c.email || '';
        document.getElementById('cust-social').value = c.social || '';
        document.getElementById('cust-address').value = c.address || '';
        document.getElementById('cust-notes').value = c.notes || '';
      }
    } else {
      modalTitle.textContent = 'เพิ่มลูกค้าใหม่';
    }
    
    const modal = new bootstrap.Modal(document.getElementById('customerModal'));
    modal.show();
  };

  customerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('customer-id').value;
    const formData = {
      name: document.getElementById('cust-name').value,
      company: document.getElementById('cust-company').value,
      taxId: document.getElementById('cust-taxId').value,
      phone: document.getElementById('cust-phone').value,
      email: document.getElementById('cust-email').value,
      social: document.getElementById('cust-social').value,
      address: document.getElementById('cust-address').value,
      notes: document.getElementById('cust-notes').value,
    };

    const btn = document.getElementById('btn-save-customer');
    btn.disabled = true;

    try {
      const url = id ? `/api/customers/${id}` : '/api/customers';
      const method = id ? 'PUT' : 'POST';
      
      const res = await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token 
        },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        alert('บันทึกข้อมูลสำเร็จ');
        bootstrap.Modal.getInstance(document.getElementById('customerModal')).hide();
        loadCustomers();
      } else {
        const data = await res.json();
        alert('เกิดข้อผิดพลาด: ' + (data.message || 'ไม่สามารถบันทึกได้'));
      }
    } catch (e) {
      alert('เกิดข้อผิดพลาดในการเชื่อมต่อ');
    } finally {
      btn.disabled = false;
    }
  });

  sendBtn.addEventListener('click', async () => {
    const message = document.getElementById('line-message-text').value;
    if (!message || !currentLineUserId) {
        alert('กรุณากรอกข้อความ');
        return;
    }

    sendBtn.disabled = true;
    try {
      const res = await fetch('/api/customers/send-message', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token 
        },
        body: JSON.stringify({ lineUserId: currentLineUserId, message })
      });

      const data = await res.json();
      if (res.ok) {
        alert('ส่งข้อความสำเร็จ');
        bootstrap.Modal.getInstance(document.getElementById('sendMessageModal')).hide();
      } else {
        alert('ส่งข้อความไม่สำเร็จ: ' + (data.message || 'Unknown error'));
      }
    } catch (e) {
      alert('เกิดข้อผิดพลาดในการส่งข้อความ');
    } finally {
      sendBtn.disabled = false;
    }
  });

  loadCustomers();
});
