# My-Studio 2.0.0 - Development Notes

## Recent Updates (2026-05-12)

### 1. Multi-Bot System (Customer & Office)
- **Architecture:** Implemented a "Smart Webhook" that distinguishes between the **Customer Bot** (Studio Admin) and **Office Bot** (Studio Admin office) using signature verification and destination mapping.
- **Office Bot Features:** 
  - Administrative commands: `สรุปงานวันนี้`, `ยอดค้างชำระ`.
  - Dedicated AI Personality: Acts as a Studio Management Assistant (not a booking agent).
- **Configuration:** Added `LINE_ADMIN_ACCESS_TOKEN` and `LINE_ADMIN_SECRET` to `.env` to separate credentials.

### 2. Automated Booking System
- **Feature:** Added a regex-based parser in the LINE webhook to automatically detect booking information (Date, Time, Type) from customer messages.
- **Persistence:** Automatically saves bookings to the MongoDB database with a `Pending` status.
- **Notifications:** Triggers an automatic push notification to the Office Bot whenever a new booking is saved.

### 3. LINE Webhook Body Parser & Security
- **Fix:** Moved `express.json()` before the LINE webhook and added a `verify` function to capture `req.rawBody` for reliable signature verification.
- **Verification:** Improved signature checking to try both Customer and Admin secrets sequentially.

### 4. Code Maintenance
- **Refactoring:** Unified the webhook endpoint `/api/line/webhook` to handle both bots, reducing redundant code.
- **Logging:** Added detailed debug logging for troubleshooting connection issues (now stabilized).

## Testing Strategy
- **Manual Verification:** Both bots confirmed working independently with separate logic.
- **Integration:** Booking submission from LINE successfully creates records in the dashboard.
- **Legacy Tests:** `tests/api.test.js` and `tests/security.test.js` remain valid and passing.

## Security Notes
- **Secret Protection:** Multi-bot secrets are now properly isolated in environment variables.
- **Static Files:** Client-side protection exists; server-side session cookies are recommended for future security hardening.
