const { GoogleGenerativeAI } = require('@google/generative-ai');
const Settings = require('../models/Settings');

// Ensure env is loaded
require('dotenv').config();

let apiKey = process.env.GEMINI_API_KEY || '';
let genAI = apiKey ? new GoogleGenerativeAI(apiKey) : null;

/**
 * Refresh API Key from DB
 */
async function refreshConfig() {
  try {
    const settings = await Settings.findOne();
    if (settings && settings.apiKeys && settings.apiKeys.geminiApiKey) {
      apiKey = settings.apiKeys.geminiApiKey;
      genAI = new GoogleGenerativeAI(apiKey);
      console.log('✅ Gemini Service: API Key loaded from DB settings');
    }
  } catch (err) {
    console.error('❌ Gemini Service: Failed to refresh config from DB:', err.message);
  }
}

// Initial load attempt
refreshConfig();

/**
 * Reusable function to call Gemini API with retries and error handling
 */
async function callGemini(prompt, options = {}) {
  if (!genAI) await refreshConfig();
  if (!genAI) {
    throw new Error('Gemini API Key is not configured. Please set it in Settings.');
  }

  // Use gemini-flash-latest which is confirmed to work in this environment
  const model = genAI.getGenerativeModel({ model: options.model || 'gemini-flash-latest' });

  let retries = options.retries || 2;
  let lastError;

  while (retries >= 0) {
    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      lastError = error;
      console.warn(`Gemini API call failed, retries left: ${retries}`, error.message);
      retries--;
      if (retries >= 0) await new Promise(res => setTimeout(res, 1000));
    }
  }

  throw new Error(`Gemini API failed after retries: ${lastError.message}`);
}

module.exports = { callGemini, refreshConfig };
