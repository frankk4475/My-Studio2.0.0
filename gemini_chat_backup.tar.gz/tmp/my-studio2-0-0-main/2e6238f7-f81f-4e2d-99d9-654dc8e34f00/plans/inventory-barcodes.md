# Implementation Plan: Inventory Expansion (Loans & Barcodes)

## Objective
Enhance the existing Inventory and Task (Assignment) modules to support formal equipment loan/withdrawal documents and comprehensive barcode tracking (scanning and generation).

## Scope & Impact
- **Database:** `Equipment` and `Assignment` models will be expanded.
- **Backend:** API routes will be updated to handle barcodes and generate unique loan document numbers.
- **Frontend:** `inventory.html` and `tasks.html` will be heavily modified to include barcode scanning/printing and form generation. A new `loan-detail.html` will be created for printing.
- **Dependencies:** We will add frontend libraries via CDN (`JsBarcode` for generation, `html5-qrcode` for camera scanning).

## Phased Implementation Plan

### Phase 1: Database & Backend Updates
1.  **Modify `Equipment.js`:** Add a `barcode` field (String, unique, sparse).
2.  **Modify `Assignment.js`:** 
    - Add `documentNumber` (String, e.g., "LN-202310...").
    - Add `expectedReturnDate` (Date).
3.  **Update API Routes (`equipment.js`, `assignments.js`):** Ensure new fields are accepted, validated, and returned. Auto-generate `documentNumber` on assignment creation.

### Phase 2: Inventory & Barcode Generation
1.  **Update `inventory.html` & `inventory.js`:**
    - Add a "Barcode" column.
    - Add barcode input to Add/Edit modals.
    - Add a "Print Barcode" button to each item.
2.  **Integrate JsBarcode:** When "Print Barcode" is clicked, render the barcode in a hidden/modal div using `JsBarcode` and trigger the browser's print dialog scoped to that barcode.

### Phase 3: Loan Forms & Barcode Scanning (Tasks)
1.  **Update `tasks.html` & `tasks.js`:**
    - Rename UI elements to reflect "ใบยืม/ใบเบิกอุปกรณ์" (Loan/Withdrawal Form).
    - In the "Assign" modal, add an input field dedicated to physical barcode scanners (listens for 'Enter' key).
    - Add a "Scan Camera" button integrating `html5-qrcode` to read barcodes via mobile/webcam.
    - Logic: Scanning a barcode auto-checks the corresponding equipment in the list.
2.  **Add Print Button:** Add a "พิมพ์ใบเบิก" (Print Loan Form) button to each assignment card.

### Phase 4: Printable Loan Document
1.  **Create `loan-detail.html` (and `.js`):**
    - Build a printable A4 layout similar to `invoices.html` or `billing-detail.html`.
    - Display document number, date, employee name, booking details, and a table of borrowed equipment.
    - Include signature lines for "ผู้เบิก" (Borrower) and "ผู้อนุมัติ" (Approver).

## Verification & Testing
- Ensure existing assignments do not break when the model updates.
- Test barcode generation by printing and scanning with a mobile app.
- Test both physical keyboard-scanner input and camera input.
- Verify the printed A4 layout looks correct in browser print preview.
