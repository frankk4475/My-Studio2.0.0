# System Enhancement & Refactoring Plan

## Background & Motivation
The current My-Studio system exhibits severe architectural inconsistencies, notably utilizing both MongoDB (via Mongoose in `index.js`) and a custom JSON file-based database (`routes/quotes.js`). The monolithic `index.js` file is overly large, making maintenance difficult. Furthermore, several critical security dependencies used in the code are missing from `package.json`. This plan addresses these structural and security issues while introducing intelligent features powered by the Gemini API to assist professional photographers.

## Scope & Impact
- **Architecture**: Modularizing models and routes; unifying all database operations to MongoDB.
- **Security**: Fixing missing dependencies (`helmet`, `cors`, `express-rate-limit`) and ensuring proper input validation.
- **AI Integration**: Adding reusable Gemini API functions and implementing three new AI-driven features (Auto-Quote, Comms Assistant, Creative Director).
- **Quality Assurance**: Adding unit tests and API documentation.
- **Impact**: Zero downtime is expected if the file database data isn't considered production data. If it is, a manual migration step will be required (handled in this plan).

## Proposed Solution

### Phase 1: Dependency & Environment Setup
1. Update `package.json` to include `helmet`, `cors`, `express-rate-limit`, `jest`, `supertest`, `swagger-ui-express`, and `@google/genai` (or `@google/generative-ai` depending on SDK preference).
2. Ensure `.env` includes `MONGO_URI`, `JWT_SECRET`, and `GEMINI_API_KEY`.

### Phase 2: Codebase Modularization & Database Unification
1. **Models**: Extract Mongoose schemas from `index.js` into separate files in the `models/` directory:
   - `models/Booking.js`
   - `models/Quote.js`
   - `models/Invoice.js`
   - `models/User.js`
   - Ensure consistency with existing `Settings.js`.
2. **Routes**: Extract route logic from `index.js` to the `routes/` directory:
   - `routes/auth.js` (Login/Register)
   - `routes/bookings.js`
   - `routes/invoices.js`
   - `routes/quotes.js`: **CRITICAL** - Rewrite this file completely to use the Mongoose `Quote` model instead of the local `routes/db.js` file system. Implement the quote-to-invoice logic natively with Mongoose transactions or sequential saves.
3. **App Setup**: Refactor `index.js` to purely act as the Express server setup, middleware configurator, and route registrar.

### Phase 3: Security & Code Quality Improvements
1. Implement input validation using a library like `Joi` or `Zod` (or manual checks) before Mongoose operations to prevent NoSQL injection and mass assignment.
2. Refactor promise chains to clean `async/await` syntax, reducing nesting.
3. Review JWT logic to ensure tokens are securely handled and verified in the auth middleware.

### Phase 4: Gemini LLM Integration
1. **Core Service**: Create `services/geminiService.js` containing a reusable Node.js function with error handling and retry logic to call the Gemini API using `GEMINI_API_KEY`.
2. **Feature: Auto-Quote Generator**: Create an endpoint that takes raw booking details and uses Gemini to suggest structured quote items (description, estimated quantity, price).
3. **Feature: Client Comms Assistant**: Create an endpoint that generates professional email drafts for sending quotes or follow-up invoices based on the document's context.
4. **Feature: Creative Director (Shot Lists)**: Implement a system prompt to analyze a booking's details (e.g., Wedding vs. Portrait) and return a suggested shot list and equipment/lighting setup.

### Phase 5: Documentation & Testing
1. **Testing**: Write unit tests using Jest/Supertest covering key endpoints (e.g., booking creation, quote generation, and auth).
2. **Documentation**: Generate Swagger-style API documentation using `swagger-jsdoc` and `swagger-ui-express`.
3. **README**: Generate a comprehensive `README.md` documenting setup, architecture, and API usage.

## Verification
- Run unit tests to verify endpoint functionality.
- Manually test the quote-to-invoice conversion to ensure business logic remains intact.
- Verify Gemini API integrations return expected JSON/Text structures.
- Ensure the app boots without missing dependency errors.

## Migration & Rollback
- Backup `data.json` before removing `routes/db.js` logic.
- If data exists in `data.json`, a one-time migration script will be needed to import `quotes` and `invoices` into MongoDB.
- Rollback can be achieved using Git version control, as no external schemas are being irreversibly mutated outside of standard development practices.